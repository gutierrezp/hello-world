import { Component, OnInit } from '@angular/core';
//import { CORE_DIRECTIVES } from '@angular/common';
import { DataService } from './data.service';
import { Person } from './person';

@Component({
    selector: 'my-app',
    providers: [DataService],
    template: `
    <h1>{{title}}</h1>
    <ul class="heroes">
        <li *ngFor="let item of myItems">
        <span class="badge">{{item.account}}</span>
        <span>{{item.name}}</span>
        </li>
    </ul>
  `,
    //directives: [CORE_DIRECTIVES]
})

export class PersonComponent implements OnInit {
    public myItems: Person [];

    constructor(private _dataService: DataService) { }

    ngOnInit() {
        this.getAllItems();
    }
    
    //...

    private getAllItems(): void {
        this._dataService
            .GetAll()
            .subscribe((data:Person[]) => this.myItems = data,
                error => console.log(error),
                () => console.log('Get all Items complete'));
    }
}