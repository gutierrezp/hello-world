import { NgModule }       from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { HttpModule }    from '@angular/http';
import { PersonComponent } from './person.component';
import { DataService } from './data.service';
import { Configuration } from './configuration';
import './rxjs-extensions';

// Imports for loading & configuring the in-memory web api
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  declarations: [
    PersonComponent
  ],
  providers: [
    DataService,
    Configuration
  ],
  bootstrap: [ PersonComponent ]
})
export class AppModule {
}
