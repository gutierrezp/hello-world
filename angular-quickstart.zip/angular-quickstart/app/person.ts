export class Person {
  name: string;
  account: number;
  salary: number;
}
